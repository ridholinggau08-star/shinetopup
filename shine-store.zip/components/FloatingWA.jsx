import { STORE } from '@/config/store';
export default function FloatingWA(){return <a href={'https://wa.me/'+STORE.wa}>WA</a>}